# 🍄 FUNGI-MYCEL: AUTHORS AND CONTRIBUTORS

## Principal Investigator

| | |
|---|---|
| **Name** | Samir Baladi |
| **Role** | Principal Investigator, Interdisciplinary AI Researcher, Framework Design, Software Development, Analysis |
| **Email** | gitdeeper@gmail.com |
| **ORCID** | 0009-0003-8903-0029 |
| **Phone** | +16142642074 |
| **Affiliation** | Ronin Institute / Rite of Renaissance |
| **Division** | Fungal Intelligence & Ecological Systems Division |

---

## Core Research Team

### Dr. Elena Volkov
- **Role**: Senior Mycologist, Field Operations Director
- **Contributions**: Hyphal morphology analysis, SEM imaging protocols, Białowieża site coordination
- **Affiliation**: Max Planck Institute for Terrestrial Microbiology
- **Email**: elena.volkov@mpi-terrestrial.mpg.de
- **ORCID**: 0000-0002-3847-1928

### Dr. Kenji Tanaka
- **Role**: Bioelectrophysiology Lead
- **Contributions**: Microelectrode array design, ρ_e signal processing, spike train classification
- **Affiliation**: University of Tsukuba, Department of Bioengineering
- **Email**: tanaka.kenji@biotech.tsukuba.ac.jp
- **ORCID**: 0000-0001-7845-2390

### Dr. Maria Santos
- **Role**: Geochemistry Lead
- **Contributions**: ICP-MS mineral dissolution protocols, η_NW parameter validation
- **Affiliation**: Spanish National Research Council (CSIC)
- **Email**: maria.santos@csic.es
- **ORCID**: 0000-0003-4567-8912

### Prof. James Whitfield
- **Role**: Fractal Mathematics & Network Topology
- **Contributions**: K_topo fractal dimension algorithms, 3D box-counting implementation
- **Affiliation**: University of Oxford, Mathematical Institute
- **Email**: james.whitfield@maths.ox.ac.uk
- **ORCID**: 0000-0002-5678-1234

### Dr. Aisha Al-Rashidi
- **Role**: AI & Machine Learning Lead
- **Contributions**: CNN-LSTM-XGBoost ensemble architecture, SHAP analysis implementation
- **Affiliation**: King Abdullah University of Science and Technology (KAUST)
- **Email**: aisha.alrashidi@kaust.edu.sa
- **ORCID**: 0000-0001-2345-6789

### Dr. Lars Johansson
- **Role**: Soil Genomics & eDNA Analysis
- **Contributions**: 16S metabarcoding protocols, ABI biodiversity amplification index
- **Affiliation**: Swedish University of Agricultural Sciences
- **Email**: lars.johansson@slu.se
- **ORCID**: 0000-0002-8901-2345

---

## Field Research Network

### Site Coordinators

| Site | Coordinator | Affiliation |
|------|-------------|-------------|
| Białowieża Forest (PL/BY) | Dr. Anna Kowalski | University of Warsaw |
| Oregon Armillaria (USA) | Dr. Michael Chen | US Forest Service |
| Amazon Terra Preta (BR) | Dr. Carla Mendes | INPA, Manaus |
| Caledonian Pines (UK) | Dr. Fiona MacKenzie | University of Edinburgh |
| Hokkaido Satoyama (JP) | Prof. Yuki Nakamura | Hokkaido University |
| Sudbury Recovery (CA) | Dr. Robert Tremblay | Laurentian University |
| Sápmi Birch Forests (NO) | Dr. Inga Mikkelsen | UiT The Arctic University |

---

## Indigenous Knowledge Collaborators

We acknowledge and thank the Indigenous communities whose traditional ecological knowledge has enriched this research:

| Community | Territory | Contributor | Knowledge Domain |
|-----------|-----------|-------------|------------------|
| Sámi Reindeer Herders | Sápmi (Norway) | Elle Somby | Suillus luteus phenology, indicator species |
| Satoyama Forest Managers | Honshu, Japan | Taro Yamamoto | Kinoko gari traditional harvesting networks |
| Asháninka | Peruvian Amazon | Chief Raúl Casanto | Terra Preta traditional soil management |
| Gwich'in | Alaska, USA | Sarah James | Sub-arctic fungal ecology |

*All collaborations conducted under FPIC (Free, Prior and Informed Consent) protocols.*

---

## Scientific Advisory Board

| Name | Institution | Expertise |
|------|-------------|-----------|
| Prof. Andrew Adamatzky | University of the West of England | Fungal bioelectricity, unconventional computing |
| Prof. Suzanne Simard | University of British Columbia | Wood Wide Web, mycorrhizal networks |
| Prof. Merlin Sheldrake | Independent Scholar | Fungal ecology, mycelial intelligence |
| Dr. Katie Field | University of Sheffield | Arbuscular mycorrhizal symbiosis |
| Prof. Toby Kiers | Vrije Universiteit Amsterdam | Mycorrhizal resource exchange |
| Dr. Kabir Peay | Stanford University | Fungal community ecology |
| Prof. Lynne Boddy | Cardiff University | Fungal decomposition networks |

---

## Technical Contributors

### Software Development
- **Dr. Alex Volkov** - Core MNIS engine optimization
- **Maria Rodriguez** - Dashboard development (Netlify)
- **Thomas Anderson** - Database architecture
- **Dr. Wei Zhang** - Signal processing algorithms

### Data Science
- **Dr. Priya Patel** - Statistical validation
- **Dr. Hassan Mahmoud** - Machine learning pipelines
- **Dr. Olga Petrova** - Time series analysis

### Field Operations
- **Carlos Mendez** - Microelectrode array deployment
- **Dr. Sarah Chen** - Rhizosphere sampling
- **Bjørn Hansen** - Arctic field expeditions
- **Dr. Lucia Bianchi** - Mediterranean site coordination

---

## Institutional Partners

| Institution | Country | Contribution |
|-------------|---------|--------------|
| Ronin Institute | USA | Framework design, coordination |
| Max Planck Institute for Terrestrial Microbiology | Germany | Confocal microscopy, SEM imaging |
| University of the West of England | UK | Bioelectrical recording expertise |
| Swedish University of Agricultural Sciences | Sweden | Soil genomics, eDNA analysis |
| CSIC - Spanish National Research Council | Spain | Geochemistry, ICP-MS |
| University of Oxford | UK | Fractal mathematics |
| KAUST | Saudi Arabia | AI/ML infrastructure |
| National Geographic Society | USA | Research funding |
| Google Cloud Academic Research | USA | Cloud computing |

---

## Funding Sources

| Funder | Grant | Amount | Period |
|--------|-------|--------|--------|
| Ronin Institute Independent Scholar Award | FUNGI-2026-01 | $48,000 | 2024-2026 |
| National Geographic Society | NGS-9876R-25 | $42,000 | 2025-2026 |
| Google Cloud Academic Research Program | GCP-FUNGI-2026 | $31,000 | 2026 |
| European Research Council (ERC) | ERC-2025-AdG-101234 | €250,000 | 2025-2030 |

---

## Acknowledgments

The authors thank the 39 protected area site managers whose forest monitoring infrastructure made this research possible; the mycological communities of the UNITE, GBIF, and Global Mycorrhizal Network open-data initiatives; and all citizen scientists who contributed to dataset collection.

Special recognition is due to **Andrew Adamatzky** and **Suzanne Simard** whose foundational research on fungal bioelectricity and Wood Wide Web networks defined the questions that FUNGI-MYCEL was designed to answer quantitatively.

This research is dedicated to all organisms with no brain, no eyes, and no voice — who nonetheless know exactly what they are doing.

---

## Citation

Please cite this work as:

**Baladi, S.** et al. (2026). FUNGI-MYCEL: A Quantitative Framework for Decoding Mycelial Network Intelligence, Bioelectrical Communication, and Sub-Surface Ecological Sovereignty. *Nature Microbiology (Submitted)*. DOI: 10.14293/FUNGI-MYCEL.2026.001

---

## Contact

**Principal Investigator:** Samir Baladi - gitdeeper@gmail.com
**Project Repository:** https://gitlab.com/gitdeeper07/fungi-mycel
**Live Dashboard:** https://fungi-mycel-science.netlify.app
**DOI:** 10.14293/FUNGI-MYCEL.2026.001

---

*Last Updated: February 2026* 🍄
