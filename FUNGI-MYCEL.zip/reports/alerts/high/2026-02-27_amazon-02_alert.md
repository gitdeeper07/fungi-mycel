# 🟠 HIGH ALERT: amazon-02

**Site:** amazon-02 (Terra Preta, Brazil)
**MNIS:** 0.71 (CRITICAL)
**Timestamp:** 2026-02-27 04:15 UTC

## Parameters
- η_NW: 0.34 (CRITICAL)
- SER: 1.38 (PARASITIC)

## Action Required
📊 **Weekly monitoring required**
- Monitor η_NW weekly
- Soil phosphorus analysis
- Indigenous knowledge consultation

**Deadline:** 2026-03-07
**Contact:** Dr. Carla Mendes
