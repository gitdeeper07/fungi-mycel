"""
FUNGI-MYCEL Command Line Interface

Provides command-line access to all framework functionality.
"""

from fungi_mycel.cli.main import main, cli

__all__ = ['main', 'cli']
