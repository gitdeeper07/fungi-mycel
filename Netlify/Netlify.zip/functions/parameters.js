// parameters.js - FUNGI-MYCEL Parameters API
exports.handler = async (event, context) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  try {
    const parameters = [
      { 
        symbol: 'η_NW', 
        name: 'Natural Weathering Efficiency', 
        weight: 18, 
        value: 0.72, 
        description: 'Measures mineral dissolution rate by fungal hyphae.',
        color: '#8fbe5a'
      },
      { 
        symbol: 'ρ_e', 
        name: 'Bioelectrical Pulse Density', 
        weight: 18, 
        value: 0.68, 
        description: 'Electrical spike train frequency and structure.',
        color: '#6a9fb5'
      },
      { 
        symbol: '∇C', 
        name: 'Chemotropic Navigation', 
        weight: 14, 
        value: 0.71, 
        description: 'Hyphal tip navigation accuracy toward resources.',
        color: '#d4a843'
      },
      { 
        symbol: 'SER', 
        name: 'Symbiotic Exchange Ratio', 
        weight: 12, 
        value: 1.05, 
        description: 'Host-fungal nutrient transaction fidelity.',
        color: '#1EDFC8'
      },
      { 
        symbol: 'K_topo', 
        name: 'Topological Expansion', 
        weight: 10, 
        value: 1.72, 
        description: 'Fractal dimension of mycelial architecture.',
        color: '#c97c5d'
      },
      { 
        symbol: 'E_a', 
        name: 'Adaptive Resilience', 
        weight: 16, 
        value: 0.65, 
        description: 'Stress response and recovery capacity.',
        color: '#9B59B6'
      },
      { 
        symbol: 'ABI', 
        name: 'Biodiversity Amplification', 
        weight: 7, 
        value: 1.84, 
        description: 'Rhizosphere biodiversity enrichment ratio.',
        color: '#E67E22'
      },
      { 
        symbol: 'BFS', 
        name: 'Field Stability', 
        weight: 5, 
        value: 0.58, 
        description: 'Post-disturbance recovery half-time.',
        color: '#d97a7a'
      }
    ];

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(parameters)
    };

  } catch (error) {
    console.error('Error in parameters function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
