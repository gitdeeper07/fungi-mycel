// sites.js - FUNGI-MYCEL Sites API
// Return ALL 39 sites

const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event, context) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  try {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Database not configured' })
      };
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // جلب ALL sites - NO LIMIT
    const { data: sites, error: sitesError } = await supabase
      .from('sites')
      .select('*')
      .order('name');

    if (sitesError) throw sitesError;

    console.log(`Returning ${sites.length} sites`);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(sites)
    };

  } catch (error) {
    console.error('Error in sites function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
