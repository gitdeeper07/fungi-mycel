// alerts.js - FUNGI-MYCEL Alerts API
// جلب الإنذارات النشطة من قاعدة البيانات الحقيقية

const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event, context) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  try {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Database not configured' })
      };
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // جلب الإنذارات النشطة مع معلومات المواقع
    const { data: alerts, error } = await supabase
      .from('alerts')
      .select(`
        id,
        site_id,
        alert_type,
        thd_value,
        gust_probability,
        predicted_gust_speed,
        lead_time_seconds,
        severity,
        message,
        status,
        created_at,
        resolved_at,
        verified,
        actual_gust_speed,
        notes,
        sites!inner (
          name,
          location,
          country,
          latitude,
          longitude
        )
      `)
      .eq('status', 'active')
      .order('severity', { ascending: false })
      .order('created_at', { ascending: false });

    if (error) throw error;

    // تنسيق البيانات للإرجاع
    const formattedAlerts = alerts.map(alert => ({
      id: alert.id,
      site_id: alert.site_id,
      site_name: alert.sites?.name || 'Unknown',
      location: alert.sites?.location || 'Unknown',
      country: alert.sites?.country,
      coordinates: {
        lat: alert.sites?.latitude,
        lng: alert.sites?.longitude
      },
      alert_type: alert.alert_type,
      thd_value: alert.thd_value,
      gust_probability: alert.gust_probability,
      predicted_gust_speed: alert.predicted_gust_speed,
      lead_time_seconds: alert.lead_time_seconds,
      severity: alert.severity,
      severity_level: alert.severity >= 4 ? 'critical' : alert.severity >= 3 ? 'high' : alert.severity >= 2 ? 'medium' : 'low',
      message: alert.message,
      status: alert.status,
      created_at: alert.created_at,
      resolved_at: alert.resolved_at,
      verified: alert.verified,
      actual_gust_speed: alert.actual_gust_speed,
      notes: alert.notes
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(formattedAlerts)
    };

  } catch (error) {
    console.error('Error in alerts function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
