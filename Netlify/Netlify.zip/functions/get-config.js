// get-config.js - FUNGI-MYCEL Config API
// جلب إعدادات المشروع من قاعدة البيانات الحقيقية

const { createClient } = require('@supabase/supabase-js');

exports.handler = async function(event, context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  try {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Database not configured' })
      };
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // جلب إحصائيات التكوين
    const { data: stats, error: statsError } = await supabase
      .from('statistics')
      .select('stat_key, stat_value, stat_string')
      .in('stat_key', ['total_sites', 'total_mnus', 'mnis_accuracy', 'study_period', 'biomes_count']);

    // جلب تعريفات المعاملات
    const { data: parameters, error: paramsError } = await supabase
      .from('parameter_definitions')
      .select('symbol, name, weight, min_range, max_range, category');

    // جلب آخر تقرير
    const { data: lastReport, error: reportError } = await supabase
      .from('reports')
      .select('report_id, title, created_at')
      .order('created_at', { ascending: false })
      .limit(1);

    // تحويل الإحصائيات إلى كائن
    const statsObj = {};
    stats?.forEach(s => {
      statsObj[s.stat_key] = s.stat_value || s.stat_string;
    });

    const config = {
      project: 'FUNGI-MYCEL',
      version: '1.0.0',
      description: 'Mycelial Network Intelligence Framework',
      research: {
        mnis_accuracy: statsObj.mnis_accuracy || 91.8,
        total_sites: statsObj.total_sites || 39,
        total_mnus: statsObj.total_mnus || 2648,
        study_period: statsObj.study_period || '2007-2026',
        biomes_count: statsObj.biomes_count || 5,
        biomes: ['Temperate Broadleaf', 'Boreal Conifer', 'Tropical Montane', 'Mediterranean Woodland', 'Sub-arctic Birch']
      },
      parameters: {
        count: parameters?.length || 8,
        list: parameters?.map(p => ({
          symbol: p.symbol,
          name: p.name,
          weight: p.weight,
          range: [p.min_range, p.max_range],
          category: p.category
        })) || []
      },
      endpoints: {
        sites: '/.netlify/functions/sites',
        parameters: '/.netlify/functions/parameters',
        alerts: '/.netlify/functions/alerts',
        stats: '/.netlify/functions/stats',
        measurements: '/.netlify/functions/measurements',
        open_sources: '/.netlify/functions/open-sources',
        reports: '/.netlify/functions/reports'
      },
      thresholds: {
        excellent: 0.25,
        good: 0.44,
        moderate: 0.62,
        critical: 0.80
      },
      last_report: lastReport && lastReport.length > 0 ? {
        id: lastReport[0].report_id,
        title: lastReport[0].title,
        date: lastReport[0].created_at
      } : null,
      supabase_configured: true,
      timestamp: new Date().toISOString()
    };

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(config, null, 2)
    };

  } catch (error) {
    console.error('Error in config function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal Server Error',
        message: error.message 
      })
    };
  }
};
