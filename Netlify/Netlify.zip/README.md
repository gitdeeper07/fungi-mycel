# 🍄 FUNGI-MYCEL Netlify Deployment

## Project Overview
FUNGI-MYCEL is a comprehensive framework for decoding mycelial network intelligence, bioelectrical communication, and sub-surface ecological sovereignty. This repository contains the Netlify deployment configuration for the live dashboard and documentation.

## Live Site
- **Main Site:** [https://fungi-mycel.netlify.app](https://fungi-mycel.netlify.app)
- **Dashboard:** [https://fungi-mycel.netlify.app/dashboard](https://fungi-mycel.netlify.app/dashboard)
- **Documentation:** [https://fungi-mycel.netlify.app/documentation](https://fungi-mycel.netlify.app/documentation)
- **Reports:** [https://fungi-mycel.netlify.app/reports](https://fungi-mycel.netlify.app/reports)

## Project Statistics
- **MNIS Accuracy:** 91.8%
- **Dataset:** 2,648 Mycelial Network Units
- **Sites:** 39 protected forests
- **Biomes:** 5 categories
- **Study Period:** 19 years (2007–2026)

## Directory Structure
```

Netlify/
├── public/           # Static HTML/CSS/JS files (index, dashboard, docs, reports)
├── functions/        # Netlify serverless functions
├── config/           # Configuration files
├── netlify.toml      # Netlify deployment configuration
├── package.json      # Node.js dependencies
└── README.md         # This file

```

## Quick Start

### Local Development
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Start local development server
netlify dev
```

Deployment

```bash
# Deploy to Netlify
netlify deploy --prod
```

Environment Variables

Copy .env.example to .env and configure:

· SITE_NAME: Site name
· SITE_URL: Production URL
· API_BASE_URL: Backend API endpoint
· AUTHOR_EMAIL: Contact email

Serverless Functions

The functions/ directory contains Netlify Functions:

· get-stats.js - Fetch MNIS statistics
· get-config.js - Get site configuration
· sites.js - List monitoring sites
· alerts.js - Get active alerts
· parameters.js - Get parameter values

Key Results

Metric Value
MNIS Accuracy 91.8%
Early Warning 42 days
ρ_e × K_topo r = +0.917
Sites 39
MNUs 2,648
Biomes 5

Author

Samir Baladi

· Email: gitdeeper@gmail.com
· ORCID: 0009-0003-8903-0029
· Affiliation: Ronin Institute

License

MIT License

Citation

```bibtex
@article{baladi2026fungiMycel,
  title={FUNGI-MYCEL: A Quantitative Framework for Decoding Mycelial Network Intelligence},
  author={Baladi, Samir},
  journal={Nature Microbiology (Submitted)},
  year={2026},
  doi={10.14293/FUNGI-MYCEL.2026.001}
}
```

---

🍄 The forest speaks. FUNGI-MYCEL translates.
